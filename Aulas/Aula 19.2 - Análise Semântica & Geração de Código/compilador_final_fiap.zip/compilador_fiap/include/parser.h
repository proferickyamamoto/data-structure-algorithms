#pragma once
#include "lexer.h"
#include "token.h"

// Inicializa o parser (pega o primeiro token)
void parser_init(Lexer *L);

// Ativa/Desativa ações de semântica+codegen dentro do parser
//   enable = 0 -> parser faz APENAS verificação sintática
//   enable = 1 -> parser também chama semantic.h e codegen.h
void parser_enable_actions(int enable);

// Faz o parse do programa inteiro (espera consumir até T_EOF)
void parse_program(Lexer *L);
