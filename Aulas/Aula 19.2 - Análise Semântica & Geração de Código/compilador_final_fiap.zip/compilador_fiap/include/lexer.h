#pragma once
#include "token.h"

// -------------------------
// Estrutura do Lexer
// -------------------------
typedef struct {
    const char *src; // texto fonte (string C terminada em '\0')
    size_t pos;      // índice atual na string
    int line;        // linha atual (1-based)
    int col;         // coluna atual (1-based)
} Lexer;

// Inicializa o lexer com o código-fonte
void lexer_init(Lexer *L, const char *source);

// Retorna o próximo token do fluxo
Token lexer_next(Lexer *L);
