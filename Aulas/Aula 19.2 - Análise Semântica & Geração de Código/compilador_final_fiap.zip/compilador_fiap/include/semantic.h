#pragma once

// Inicializa a tabela de símbolos
void semantic_init();

// Verifica se 'name' pode ser declarado (erro se já existir), então insere
void semantic_check_declaration(const char *name, int line, int col);

// Verifica se 'name' já foi declarado (erro se não existir)
void semantic_check_usage(const char *name, int line, int col);

// Libera recursos (tabela de símbolos)
void semantic_finalize();
