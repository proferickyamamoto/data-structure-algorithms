#pragma once
#include <stddef.h>

// -------------------------
// Tipos de token da FIAP
// -------------------------
typedef enum {
    // Fim de arquivo
    T_EOF = 0,

    // Identificadores e números
    T_IDENT,
    T_NUMBER,

    // Palavras-chave
    T_LET,    // let
    T_PRINT,  // print
    T_IF,     // if
    T_ELSE,   // else
    T_WHILE,  // while

    // Símbolos simples
    T_SEMI,     // ;
    T_LPAREN,   // (
    T_RPAREN,   // )
    T_LBRACE,   // {
    T_RBRACE,   // }

    // Aritméticos
    T_PLUS,     // +
    T_MINUS,    // -
    T_STAR,     // *
    T_SLASH,    // /
    T_PERCENT,  // %

    // Atribuição
    T_ASSIGN,   // =

    // Comparação
    T_EQ,    // ==
    T_NEQ,   // !=
    T_LT,    // <
    T_LTE,   // <=
    T_GT,    // >
    T_GTE    // >=
} TokenType;

// -------------------------
// Estrutura do Token
// -------------------------
typedef struct {
    TokenType type;     // tipo do token
    long      value;    // valor numérico (quando T_NUMBER)
    const char *lexeme; // lexema (alocado) para T_IDENT; NULL nos demais
    int line;           // linha (1-based)
    int col;            // coluna (1-based)
} Token;

// Nome legível do token (para debug/prints)
const char* token_name(TokenType t);
