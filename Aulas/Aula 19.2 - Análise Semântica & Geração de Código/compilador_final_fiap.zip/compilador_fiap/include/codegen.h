#pragma once

// Inicializa (ex.: imprime cabeçalho)
void codegen_init();

// Emite pseudo-código para: name = value (valor literal)
void codegen_emit_assignment_const(const char *name, long value);

// Emite pseudo-código para: print name
void codegen_emit_print_var(const char *name);

// Finaliza (ex.: imprime rodapé)
void codegen_finalize();
