#include "../include/token.h"

const char* token_name(TokenType t) {
    switch (t) {
        case T_EOF: return "T_EOF";
        case T_IDENT: return "T_IDENT";
        case T_NUMBER: return "T_NUMBER";
        case T_LET: return "T_LET";
        case T_PRINT: return "T_PRINT";
        case T_IF: return "T_IF";
        case T_ELSE: return "T_ELSE";
        case T_WHILE: return "T_WHILE";
        case T_SEMI: return "T_SEMI";
        case T_LPAREN: return "T_LPAREN";
        case T_RPAREN: return "T_RPAREN";
        case T_LBRACE: return "T_LBRACE";
        case T_RBRACE: return "T_RBRACE";
        case T_PLUS: return "T_PLUS";
        case T_MINUS: return "T_MINUS";
        case T_STAR: return "T_STAR";
        case T_SLASH: return "T_SLASH";
        case T_PERCENT: return "T_PERCENT";
        case T_ASSIGN: return "T_ASSIGN";
        case T_EQ: return "T_EQ";
        case T_NEQ: return "T_NEQ";
        case T_LT: return "T_LT";
        case T_LTE: return "T_LTE";
        case T_GT: return "T_GT";
        case T_GTE: return "T_GTE";
    }
    return "T_UNKNOWN";
}
