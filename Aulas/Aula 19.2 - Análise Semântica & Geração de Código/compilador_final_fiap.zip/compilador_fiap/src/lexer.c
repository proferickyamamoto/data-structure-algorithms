#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/lexer.h"

// --- strdup portátil ---
static char* fiap_strdup(const char* s) {
    if (!s) return NULL;
    size_t n = strlen(s) + 1;
    char* p = (char*)malloc(n);
    if (!p) { perror("malloc"); exit(1); }
    memcpy(p, s, n);
    return p;
}

// --- util ---
static int is_ident_start(int c) { return isalpha(c) || c=='_'; }
static int is_ident_part (int c) { return isalnum(c) || c=='_'; }

static Token make_token(Lexer *L, TokenType t, const char *lex, long val) {
    Token tok;
    tok.type = t;
    tok.value = val;
    tok.lexeme = lex; // para IDENT usamos fiap_strdup
    tok.line = L->line;
    tok.col  = L->col;
    return tok;
}

static char peek(Lexer *L) {
    return L->src[L->pos];
}

static char getc_advance(Lexer *L) {
    char c = L->src[L->pos];
    if (c == '\0') return '\0';
    L->pos++;
    if (c == '\n') {
        L->line++;
        L->col = 1;
    } else {
        L->col++;
    }
    return c;
}

static void skip_ws_and_comments(Lexer *L) {
    for (;;) {
        char c = peek(L);
        if (c==' '||c=='\t'||c=='\r'||c=='\n') {
            getc_advance(L);
            continue;
        }
        // comentário //
        if (c=='/' && L->src[L->pos+1]=='/') {
            while (peek(L)!='\0' && peek(L)!='\n') getc_advance(L);
            continue;
        }
        break;
    }
}

// --- API ---
void lexer_init(Lexer *L, const char *source) {
    L->src = source;
    L->pos = 0;
    L->line = 1;
    L->col = 1;
}

Token lexer_next(Lexer *L) {
    skip_ws_and_comments(L);

    int start_line = L->line;
    int start_col  = L->col;
    char c = peek(L);
    if (c == '\0') {
        return make_token(L, T_EOF, NULL, 0);
    }

    // NÚMERO (inteiro)
    if (isdigit(c)) {
        long val = 0;
        while (isdigit(peek(L))) {
            val = val*10 + (getc_advance(L) - '0');
        }
        Token t = make_token(L, T_NUMBER, NULL, val);
        t.line = start_line; t.col = start_col;
        return t;
    }

    // IDENT / PALAVRA-CHAVE
    if (is_ident_start(c)) {
        size_t cap = 32, len = 0;
        char *buf = (char*)malloc(cap);
        if (!buf) { perror("malloc"); exit(1); }
        while (is_ident_part(peek(L))) {
            if (len+1 >= cap) { cap*=2; buf = (char*)realloc(buf, cap); }
            buf[len++] = getc_advance(L);
        }
        buf[len] = '\0';

        TokenType kw = T_IDENT;
        if (strcmp(buf, "let")==0)   kw = T_LET;
        else if (strcmp(buf, "print")==0) kw = T_PRINT;
        else if (strcmp(buf, "if")==0)    kw = T_IF;
        else if (strcmp(buf, "else")==0)  kw = T_ELSE;
        else if (strcmp(buf, "while")==0) kw = T_WHILE;

        Token t;
        if (kw == T_IDENT) {
            t = make_token(L, T_IDENT, fiap_strdup(buf), 0);
        } else {
            t = make_token(L, kw, NULL, 0);
        }
        free(buf);
        t.line = start_line; t.col = start_col;
        return t;
    }

    // SÍMBOLOS / OPERADORES (inclui pares de 2 chars)
    getc_advance(L); // consumir o caractere atual
    switch (c) {
        case ';': { Token t = make_token(L, T_SEMI, NULL, 0);     t.line=start_line; t.col=start_col; return t; }
        case '(': { Token t = make_token(L, T_LPAREN, NULL, 0);   t.line=start_line; t.col=start_col; return t; }
        case ')': { Token t = make_token(L, T_RPAREN, NULL, 0);   t.line=start_line; t.col=start_col; return t; }
        case '{': { Token t = make_token(L, T_LBRACE, NULL, 0);   t.line=start_line; t.col=start_col; return t; }
        case '}': { Token t = make_token(L, T_RBRACE, NULL, 0);   t.line=start_line; t.col=start_col; return t; }
        case '+': { Token t = make_token(L, T_PLUS, NULL, 0);     t.line=start_line; t.col=start_col; return t; }
        case '-': { Token t = make_token(L, T_MINUS, NULL, 0);    t.line=start_line; t.col=start_col; return t; }
        case '*': { Token t = make_token(L, T_STAR, NULL, 0);     t.line=start_line; t.col=start_col; return t; }
        case '/': { Token t = make_token(L, T_SLASH, NULL, 0);    t.line=start_line; t.col=start_col; return t; }
        case '%': { Token t = make_token(L, T_PERCENT, NULL, 0);  t.line=start_line; t.col=start_col; return t; }
        case '=':
            if (peek(L) == '=') { getc_advance(L); Token t = make_token(L, T_EQ, NULL, 0);  t.line=start_line; t.col=start_col; return t; }
            { Token t = make_token(L, T_ASSIGN, NULL, 0); t.line=start_line; t.col=start_col; return t; }
        case '!':
            if (peek(L) == '=') { getc_advance(L); Token t = make_token(L, T_NEQ, NULL, 0); t.line=start_line; t.col=start_col; return t; }
            break;
        case '<':
            if (peek(L) == '=') { getc_advance(L); Token t = make_token(L, T_LTE, NULL, 0); t.line=start_line; t.col=start_col; return t; }
            { Token t = make_token(L, T_LT, NULL, 0); t.line=start_line; t.col=start_col; return t; }
        case '>':
            if (peek(L) == '=') { getc_advance(L); Token t = make_token(L, T_GTE, NULL, 0); t.line=start_line; t.col=start_col; return t; }
            { Token t = make_token(L, T_GT, NULL, 0); t.line=start_line; t.col=start_col; return t; }
    }

    fprintf(stderr, "Erro léxico: caractere inesperado '%c' em %d:%d\n",
            c, start_line, start_col);
    exit(1);
}
