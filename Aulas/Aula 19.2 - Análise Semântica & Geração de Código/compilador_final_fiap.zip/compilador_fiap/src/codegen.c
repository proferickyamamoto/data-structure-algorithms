#include <stdio.h>
#include "../include/codegen.h"

void codegen_init() {
    printf("; Código gerado (FIAP)\n");
}

void codegen_emit_assignment_const(const char *name, long value) {
    // Exemplo simples com literais:
    printf("LOAD_CONST %ld\n", value);
    printf("STORE_VAR %s\n", name);
}

void codegen_emit_print_var(const char *name) {
    printf("LOAD_VAR %s\n", name);
    printf("PRINT_VAR %s\n", name);
}

void codegen_finalize() {
    printf("; Fim do código\n");
}
