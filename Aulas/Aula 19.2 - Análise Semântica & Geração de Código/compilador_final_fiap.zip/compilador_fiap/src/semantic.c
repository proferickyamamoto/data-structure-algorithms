#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/semantic.h"

// strdup portátil
static char* fiap_strdup(const char* s) {
    if (!s) return NULL;
    size_t n = strlen(s) + 1;
    char* p = (char*)malloc(n);
    if (!p) { perror("malloc"); exit(1); }
    memcpy(p, s, n);
    return p;
}

// Tabela de símbolos: lista ligada simples com nomes
typedef struct Sym {
    char *name;
    struct Sym *next;
} Sym;


static Sym *sym_table = NULL;

void semantic_init() {
    sym_table = NULL;
}

static int sym_exists(const char *name) {
    for (Sym *s = sym_table; s; s = s->next) {
        if (strcmp(s->name, name) == 0) return 1;
    }
    return 0;
}

static void sym_insert(const char *name) {
    Sym *s = (Sym*)malloc(sizeof(Sym));
    if (!s) { perror("malloc"); exit(1); }
    s->name = fiap_strdup(name);   // <-- aqui trocamos _strdup/strdup
    s->next = sym_table;
    sym_table = s;
}

void semantic_check_declaration(const char *name, int line, int col) {
    if (sym_exists(name)) {
        fprintf(stderr, "Erro semântico: variável '%s' já declarada em %d:%d\n", name, line, col);
        exit(1);
    }
    sym_insert(name);
}

void semantic_check_usage(const char *name, int line, int col) {
    if (!sym_exists(name)) {
        fprintf(stderr, "Erro semântico: variável '%s' não declarada em %d:%d\n", name, line, col);
        exit(1);
    }
}

void semantic_finalize() {
    Sym *s = sym_table;
    while (s) {
        Sym *n = s->next;
        free(s->name);
        free(s);
        s = n;
    }
    sym_table = NULL;
}
