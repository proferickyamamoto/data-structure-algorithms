#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/parser.h"
#include "../include/semantic.h"  // usado quando ações estão ativas
#include "../include/codegen.h"   // usado quando ações estão ativas

// Token corrente do parser
static Token current;

// Flag para habilitar semântica+codegen a partir do parser
static int g_enable_actions = 0;

// ---- Declarações das funções internas (gramática com precedência) ----
// expr        -> comp_expr
// comp_expr   -> arith_expr ( (== | != | < | <= | > | >=) arith_expr )*
// arith_expr  -> term ( (+ | -) term )*
// term        -> factor ( (* | / | %) factor )*
// factor      -> NUMBER | IDENT | "(" expr ")"

// statements: let id = expr ; | id = expr ; | print expr ; | if (...) { ... } [else { ... }] | while (...) { ... }

static void parse_statement_list(Lexer *L);
static void parse_statement(Lexer *L);
static void parse_expr(Lexer *L);
static void parse_comp_expr(Lexer *L);
static void parse_arith_expr(Lexer *L);
static void parse_term(Lexer *L);
static void parse_factor(Lexer *L);

// ---- util ----
static void advance_token(Lexer *L) { current = lexer_next(L); }
static int match(TokenType t) { return current.type == t; }

void parser_init(Lexer *L) { advance_token(L); }
void parser_enable_actions(int enable) { g_enable_actions = enable; }

// Programa completo
void parse_program(Lexer *L) {
    parse_statement_list(L);
    if (!match(T_EOF)) {
        fprintf(stderr, "Erro sintático: token inesperado '%s' em %d:%d\n",
                token_name(current.type), current.line, current.col);
        exit(1);
    }
}

// Lista de statements até EOF ou '}'
static void parse_statement_list(Lexer *L) {
    while (!match(T_EOF) && !match(T_RBRACE)) {
        parse_statement(L);
    }
}

// Um único statement
static void parse_statement(Lexer *L) {
    if (match(T_LET)) {
        // let identifier = expr ;
        advance_token(L); // consome 'let'
        if (!match(T_IDENT)) {
            fprintf(stderr, "Erro: esperado identificador após 'let' em %d:%d\n", current.line, current.col);
            exit(1);
        }
        const char *name = current.lexeme; // guardar para ações
        int id_line = current.line, id_col = current.col;
        advance_token(L); // consome IDENT

        if (!match(T_ASSIGN)) {
            fprintf(stderr, "Erro: esperado '=' em %d:%d\n", current.line, current.col);
            exit(1);
        }
        advance_token(L); // consome '='

        // Para codegen simples: aceitamos só literal NUMBER direto (didático)
        if (match(T_NUMBER)) {
            long val = current.value;
            advance_token(L);
            if (!match(T_SEMI)) {
                fprintf(stderr, "Erro: esperado ';' em %d:%d\n", current.line, current.col);
                exit(1);
            }
            if (g_enable_actions) {
                semantic_check_declaration(name, id_line, id_col);
                codegen_emit_assignment_const(name, val);
            }
            advance_token(L); // consome ';'
        } else {
            // Versão completa: permitir expr geral
            parse_expr(L);
            if (!match(T_SEMI)) {
                fprintf(stderr, "Erro: esperado ';' em %d:%d\n", current.line, current.col);
                exit(1);
            }
            // Como não avaliamos expr aqui, omitimos codegen dessa forma
            if (g_enable_actions) {
                semantic_check_declaration(name, id_line, id_col);
                // Para simplificar: não geramos código de expr geral aqui
            }
            advance_token(L);
        }
    }
    else if (match(T_PRINT)) {
        // print expr ;
        advance_token(L);
        // Se o primeiro token for IDENT e ações ativas, verificamos uso
        if (g_enable_actions && match(T_IDENT)) {
            semantic_check_usage(current.lexeme, current.line, current.col);
            codegen_emit_print_var(current.lexeme);
            advance_token(L);
            if (!match(T_SEMI)) {
                fprintf(stderr, "Erro: esperado ';' após print em %d:%d\n", current.line, current.col);
                exit(1);
            }
            advance_token(L);
        } else {
            // parsing geral
            parse_expr(L);
            if (!match(T_SEMI)) {
                fprintf(stderr, "Erro: esperado ';' em %d:%d\n", current.line, current.col);
                exit(1);
            }
            advance_token(L);
        }
    }
    else if (match(T_IF)) {
        // if ( expr ) { statement_list } [ else { statement_list } ]
        advance_token(L);
        if (!match(T_LPAREN)) { fprintf(stderr, "Erro: esperado '(' após if em %d:%d\n", current.line, current.col); exit(1); }
        advance_token(L);
        parse_expr(L);
        if (!match(T_RPAREN)) { fprintf(stderr, "Erro: esperado ')' em %d:%d\n", current.line, current.col); exit(1); }
        advance_token(L);
        if (!match(T_LBRACE)) { fprintf(stderr, "Erro: esperado '{' após if em %d:%d\n", current.line, current.col); exit(1); }
        advance_token(L);
        parse_statement_list(L);
        if (!match(T_RBRACE)) { fprintf(stderr, "Erro: esperado '}' em %d:%d\n", current.line, current.col); exit(1); }
        advance_token(L);
        if (match(T_ELSE)) {
            advance_token(L);
            if (!match(T_LBRACE)) { fprintf(stderr, "Erro: esperado '{' após else em %d:%d\n", current.line, current.col); exit(1); }
            advance_token(L);
            parse_statement_list(L);
            if (!match(T_RBRACE)) { fprintf(stderr, "Erro: esperado '}' em %d:%d\n", current.line, current.col); exit(1); }
            advance_token(L);
        }
    }
    else if (match(T_WHILE)) {
        // while ( expr ) { statement_list }
        advance_token(L);
        if (!match(T_LPAREN)) { fprintf(stderr, "Erro: esperado '(' após while em %d:%d\n", current.line, current.col); exit(1); }
        advance_token(L);
        parse_expr(L);
        if (!match(T_RPAREN)) { fprintf(stderr, "Erro: esperado ')' em %d:%d\n", current.line, current.col); exit(1); }
        advance_token(L);
        if (!match(T_LBRACE)) { fprintf(stderr, "Erro: esperado '{' após while em %d:%d\n", current.line, current.col); exit(1); }
        advance_token(L);
        parse_statement_list(L);
        if (!match(T_RBRACE)) { fprintf(stderr, "Erro: esperado '}' em %d:%d\n", current.line, current.col); exit(1); }
        advance_token(L);
    }
    else {
        // atribuição: identifier = expr ;
        if (!match(T_IDENT)) {
            fprintf(stderr, "Erro: esperado comando válido ou identificador em %d:%d\n", current.line, current.col);
            exit(1);
        }
        const char *name = current.lexeme;
        int id_line = current.line, id_col = current.col;
        advance_token(L);
        if (!match(T_ASSIGN)) { fprintf(stderr, "Erro: esperado '=' em %d:%d\n", current.line, current.col); exit(1); }
        advance_token(L);

        if (g_enable_actions) {
            // verificar uso antes de atribuir
            semantic_check_usage(name, id_line, id_col);
        }

        // versão simples: se literal
        if (match(T_NUMBER)) {
            long v = current.value;
            advance_token(L);
            if (!match(T_SEMI)) { fprintf(stderr, "Erro: esperado ';' em %d:%d\n", current.line, current.col); exit(1); }
            if (g_enable_actions) {
                codegen_emit_assignment_const(name, v);
            }
            advance_token(L);
        } else {
            // parsing completo
            parse_expr(L);
            if (!match(T_SEMI)) { fprintf(stderr, "Erro: esperado ';' em %d:%d\n", current.line, current.col); exit(1); }
            // (omitimos codegen para expr geral)
            advance_token(L);
        }
    }
}

// expr -> comp_expr
static void parse_expr(Lexer *L) {
    parse_comp_expr(L);
}

// comp_expr -> arith_expr ( (== | != | < | <= | > | >=) arith_expr )*
static void parse_comp_expr(Lexer *L) {
    parse_arith_expr(L);
    while (match(T_EQ) || match(T_NEQ) || match(T_LT) || match(T_LTE) || match(T_GT) || match(T_GTE)) {
        advance_token(L);
        parse_arith_expr(L);
    }
}

// arith_expr -> term ( (+ | -) term )*
static void parse_arith_expr(Lexer *L) {
    parse_term(L);
    while (match(T_PLUS) || match(T_MINUS)) {
        advance_token(L);
        parse_term(L);
    }
}

// term -> factor ( (* | / | %) factor )*
static void parse_term(Lexer *L) {
    parse_factor(L);
    while (match(T_STAR) || match(T_SLASH) || match(T_PERCENT)) {
        advance_token(L);
        parse_factor(L);
    }
}

// factor -> NUMBER | IDENT | '(' expr ')'
static void parse_factor(Lexer *L) {
    if (match(T_NUMBER)) {
        advance_token(L);
    } else if (match(T_IDENT)) {
        // se ações ativas e for uso em expressão, validar uso
        if (g_enable_actions) {
            semantic_check_usage(current.lexeme, current.line, current.col);
        }
        advance_token(L);
    } else if (match(T_LPAREN)) {
        advance_token(L);
        parse_expr(L);
        if (!match(T_RPAREN)) { fprintf(stderr, "Erro: esperado ')' em %d:%d\n", current.line, current.col); exit(1); }
        advance_token(L);
    } else {
        fprintf(stderr, "Erro: fator inválido em %d:%d\n", current.line, current.col);
        exit(1);
    }
}
