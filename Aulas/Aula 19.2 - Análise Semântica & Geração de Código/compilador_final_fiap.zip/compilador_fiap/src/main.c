#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/lexer.h"
#include "../include/token.h"
#include "../include/parser.h"
#include "../include/semantic.h"
#include "../include/codegen.h"

// Lê arquivo inteiro para memória
static char* read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) { perror("fopen"); exit(1); }
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buf = (char*)malloc(n + 1);
    if (!buf) { perror("malloc"); exit(1); }
    if (fread(buf, 1, n, f) != (size_t)n) { perror("fread"); exit(1); }
    buf[n] = '\0';
    fclose(f);
    return buf;
}

static void mode_tokens(const char *path) {
    char *src = read_file(path);
    Lexer L; lexer_init(&L, src);
    for (;;) {
        Token t = lexer_next(&L);
        if (t.type == T_EOF) {
            printf("T_EOF (l=%d c=%d)\n", t.line, t.col);
            break;
        }
        if (t.type == T_NUMBER) {
            printf("%s %ld (l=%d c=%d)\n", token_name(t.type), t.value, t.line, t.col);
        } else if (t.type == T_IDENT) {
            printf("%s '%s' (l=%d c=%d)\n", token_name(t.type), t.lexeme, t.line, t.col);
            free((void*)t.lexeme);
        } else {
            printf("%s (l=%d c=%d)\n", token_name(t.type), t.line, t.col);
        }
    }
    free(src);
}

static void mode_parse(const char *path) {
    char *src = read_file(path);
    Lexer L; lexer_init(&L, src);
    parser_init(&L);
    parser_enable_actions(0); // apenas sintaxe
    parse_program(&L);
    printf("Parsing concluído com sucesso.\n");
    free(src);
}

static void mode_codegen(const char *path) {
    char *src = read_file(path);
    Lexer L; lexer_init(&L, src);
    parser_init(&L);

    semantic_init();
    codegen_init();
    parser_enable_actions(1); // sintaxe + semântica + geração
    parse_program(&L);
    codegen_finalize();
    semantic_finalize();

    printf("Geração de código concluída com sucesso.\n");
    free(src);
}

int main(int argc, char **argv) {
    if (argc != 3) {
        fprintf(stderr,
          "Uso:\n"
          "  %s --tokens <arquivo.fiap>\n"
          "  %s --parse  <arquivo.fiap>\n"
          "  %s --codegen <arquivo.fiap>\n",
          argv[0], argv[0], argv[0]);
        return 1;
    }
    if (strcmp(argv[1], "--tokens") == 0) { mode_tokens(argv[2]); return 0; }
    if (strcmp(argv[1], "--parse")  == 0) { mode_parse (argv[2]); return 0; }
    if (strcmp(argv[1], "--codegen")== 0) { mode_codegen(argv[2]); return 0; }

    fprintf(stderr, "Flag inválida. Use --tokens, --parse, ou --codegen.\n");
    return 1;
}
