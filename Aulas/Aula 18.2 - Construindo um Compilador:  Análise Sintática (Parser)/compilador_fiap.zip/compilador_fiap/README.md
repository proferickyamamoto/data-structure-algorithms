# FIAP Template

Este é o template do projeto FIAP (lexer) pronto para uso.  
Use a extensão `.fiap` para seus programas-fonte.

## Como usar

1. Compile com:
make

markdown
Copiar código
2. Execute exemplo:
./fiap --tokens tests/samples/arith.fiap