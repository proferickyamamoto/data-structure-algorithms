#include <stdio.h>
#include <stdlib.h>
#include "parser.h"

static Token current;   // token corrente que o parser está “vendo”

// Avança para o próximo token no fluxo do lexer
static void advance_token(Lexer *L) {
    current = lexer_next(L);
}

// Declarações de funções internas para cada regra da gramática
static void parse_statement_list(Lexer *L);
static void parse_statement(Lexer *L);
static void parse_expr(Lexer *L);
static void parse_term(Lexer *L);
static void parse_factor(Lexer *L);

// Inicializa o parser: pega o primeiro token
void parser_init(Lexer *L) {
    advance_token(L);
}

// Analisa o programa inteiro (começa pela regra “program”)
void parse_program(Lexer *L) {
    parse_statement_list(L);
    if (current.type != T_EOF) {
        fprintf(stderr,
            "Erro sintático: token inesperado '%s' em %d:%d\n",
            token_name(current.type), current.line, current.col);
        exit(1);
    }
}

// Lista de declarações / comandos até fim ou até ‘}’ de bloco
static void parse_statement_list(Lexer *L) {
    while (current.type != T_EOF && current.type != T_RBRACE) {
        parse_statement(L);
    }
}

// Um único comando / instrução
static void parse_statement(Lexer *L) {
    if (current.type == T_LET) {
        // regra: let identifier = expr ;
        advance_token(L);  // consume ‘let’
        if (current.type != T_IDENT) {
            fprintf(stderr,
                "Erro: esperado identificador após 'let' em %d:%d\n",
                current.line, current.col);
            exit(1);
        }
        advance_token(L);  // consume o identificador
        if (current.type != T_ASSIGN) {
            fprintf(stderr,
                "Erro: esperado '=' em %d:%d\n",
                current.line, current.col);
            exit(1);
        }
        advance_token(L);  // consume '='
        parse_expr(L);     // regra expr
        if (current.type != T_SEMI) {
            fprintf(stderr,
                "Erro: esperado ';' em %d:%d\n",
                current.line, current.col);
            exit(1);
        }
        advance_token(L);  // consume ';'
    }
    else if (current.type == T_PRINT) {
        // regra: print expr ;
        advance_token(L);
        parse_expr(L);
        if (current.type != T_SEMI) {
            fprintf(stderr,
                "Erro: esperado ';' após print em %d:%d\n",
                current.line, current.col);
            exit(1);
        }
        advance_token(L);
    }
    else if (current.type == T_IF) {
        // regra: if ( expr ) { statement_list } [ else { statement_list } ]
        advance_token(L);
        if (current.type != T_LPAREN) {
            fprintf(stderr,
                "Erro: esperado '(' após if em %d:%d\n",
                current.line, current.col);
            exit(1);
        }
        advance_token(L);
        parse_expr(L);
        if (current.type != T_RPAREN) {
            fprintf(stderr,
                "Erro: esperado ')' em %d:%d\n",
                current.line, current.col);
            exit(1);
        }
        advance_token(L);
        if (current.type != T_LBRACE) {
            fprintf(stderr,
                "Erro: esperado '{' após if em %d:%d\n",
                current.line, current.col);
            exit(1);
        }
        advance_token(L);
        parse_statement_list(L);
        if (current.type != T_RBRACE) {
            fprintf(stderr,
                "Erro: esperado '}' em %d:%d\n",
                current.line, current.col);
            exit(1);
        }
        advance_token(L);
        if (current.type == T_ELSE) {
            advance_token(L);
            if (current.type != T_LBRACE) {
                fprintf(stderr,
                    "Erro: esperado '{' após else em %d:%d\n",
                    current.line, current.col);
                exit(1);
            }
            advance_token(L);
            parse_statement_list(L);
            if (current.type != T_RBRACE) {
                fprintf(stderr,
                    "Erro: esperado '}' após bloco else em %d:%d\n",
                    current.line, current.col);
                exit(1);
            }
            advance_token(L);
        }
    }
    else if (current.type == T_WHILE) {
        // regra: while ( expr ) { statement_list }
        advance_token(L);
        if (current.type != T_LPAREN) {
            fprintf(stderr,
                "Erro: esperado '(' após while em %d:%d\n",
                current.line, current.col);
            exit(1);
        }
        advance_token(L);
        parse_expr(L);
        if (current.type != T_RPAREN) {
            fprintf(stderr,
                "Erro: esperado ')' em %d:%d\n",
                current.line, current.col);
            exit(1);
        }
        advance_token(L);
        if (current.type != T_LBRACE) {
            fprintf(stderr,
                "Erro: esperado '{' após while em %d:%d\n",
                current.line, current.col);
            exit(1);
        }
        advance_token(L);
        parse_statement_list(L);
        if (current.type != T_RBRACE) {
            fprintf(stderr,
                "Erro: esperado '}' em %d:%d\n",
                current.line, current.col);
            exit(1);
        }
        advance_token(L);
    }
    else {
        // regra: <identifier> = expr ;
        if (current.type != T_IDENT) {
            fprintf(stderr,
                "Erro: esperado comando válido ou identificador em %d:%d\n",
                current.line, current.col);
            exit(1);
        }
        advance_token(L);
        if (current.type != T_ASSIGN) {
            fprintf(stderr,
                "Erro: esperado '=' em %d:%d\n",
                current.line, current.col);
            exit(1);
        }
        advance_token(L);
        parse_expr(L);
        if (current.type != T_SEMI) {
            fprintf(stderr,
                "Erro: esperado ';' após atribuição em %d:%d\n",
                current.line, current.col);
            exit(1);
        }
        advance_token(L);
    }
}

// Expressão: soma/subtração de termos
static void parse_expr(Lexer *L) {
    parse_term(L);
    while (current.type == T_PLUS || current.type == T_MINUS) {
        advance_token(L);    // consome o operador + ou -
        parse_term(L);       // consome o próximo termo
    }
}

// Termo: multiplicação/divisão/mod do fator
static void parse_term(Lexer *L) {
    parse_factor(L);
    while (current.type == T_STAR || current.type == T_SLASH || current.type == T_PERCENT) {
        advance_token(L);
        parse_factor(L);
    }
}

// Fator: número | identificador | "(" expr ")"
static void parse_factor(Lexer *L) {
    if (current.type == T_NUMBER) {
        advance_token(L);
    }
    else if (current.type == T_IDENT) {
        advance_token(L);
    }
    else if (current.type == T_LPAREN) {
        advance_token(L);
        parse_expr(L);
        if (current.type != T_RPAREN) {
            fprintf(stderr,
                "Erro: esperado ')' em %d:%d\n",
                current.line, current.col);
            exit(1);
        }
        advance_token(L);
    }
    else {
        fprintf(stderr,
            "Erro: fator inválido em %d:%d\n",
            current.line, current.col);
        exit(1);
    }
}
