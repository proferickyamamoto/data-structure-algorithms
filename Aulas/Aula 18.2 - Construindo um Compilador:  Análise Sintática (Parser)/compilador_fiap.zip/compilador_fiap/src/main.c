#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lexer.h"
#include "token.h"
#include "parser.h"

static char* read_file(const char *path) {
  FILE *f = fopen(path, "rb");
  if (!f) {
    perror("fopen");
    exit(1);
  }
  fseek(f, 0, SEEK_END);
  long n = ftell(f);
  fseek(f, 0, SEEK_SET);
  char *buf = malloc(n + 1);
  if (fread(buf, 1, n, f) != (size_t)n) {
    perror("fread");
    exit(1);
  }
  buf[n] = '\0';
  fclose(f);
  return buf;
}

int main(int argc, char **argv) {
  if (argc < 3 || strcmp(argv[1], "--parse") != 0) {
    fprintf(stderr, "Uso: %s --parse <arquivo.fiap>\n", argv[0]);
    return 1;
  }
  char *src = read_file(argv[2]);
  Lexer L;
  lexer_init(&L, src);
  parser_init(&L);
  parse_program(&L);
  printf("Parsing concluído com sucesso.\n");
  free(src);
  return 0;
}
