#pragma once
#include "lexer.h"  // inclui a definição de Lexer, para que possamos chamar lexer_next()
#include "token.h"  // inclui TokenType, Token, token_name()

// Inicializa o parser com um lexer já inicializado
void parser_init(Lexer *L);
// Analisa o programa inteiro; espera que após chamar, todos os tokens tenham sido consumidos ou erro será reportado
void parse_program(Lexer *L);
