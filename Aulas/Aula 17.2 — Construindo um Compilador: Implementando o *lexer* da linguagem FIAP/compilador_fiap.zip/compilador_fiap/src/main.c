#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/lexer.h"
#include "../include/token.h"

static char* read_file(const char *path) {
  FILE *f = fopen(path, "rb");
  if (!f) {
    perror("fopen");
    exit(1);
  }
  fseek(f, 0, SEEK_END);
  long n = ftell(f);
  fseek(f, 0, SEEK_SET);
  char *buf = malloc(n + 1);
  if (fread(buf, 1, n, f) != (size_t)n) {
    perror("fread");
    exit(1);
  }
  buf[n] = '\0';
  fclose(f);
  return buf;
}

int main(int argc, char **argv) {
  if (argc < 3 || strcmp(argv[1], "--tokens") != 0) {
    fprintf(stderr, "Uso: %s --tokens <arquivo.fiap>\n", argv[0]);
    return 1;
  }
  char *src = read_file(argv[2]);
  Lexer L;
  lexer_init(&L, src);

  while (1) {
    Token t = lexer_next(&L);
    if (t.type == T_EOF) {
      printf("T_EOF (l=%d c=%d)\n", t.line, t.col);
      break;
    }
    if (t.type == T_NUMBER) {
      printf("%s %ld (l=%d c=%d)\n",
             token_name(t.type), t.value, t.line, t.col);
    } else if (t.type == T_IDENT) {
      printf("%s '%s' (l=%d c=%d)\n",
             token_name(t.type), t.lexeme, t.line, t.col);
      free((void*)t.lexeme);
    } else {
      printf("%s '%s' (l=%d c=%d)\n",
             token_name(t.type),
             t.lexeme ? t.lexeme : "",
             t.line, t.col);
    }
  }

  free(src);
  return 0;
}
