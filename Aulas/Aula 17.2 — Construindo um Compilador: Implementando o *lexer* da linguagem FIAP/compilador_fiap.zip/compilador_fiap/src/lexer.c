#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "../include/lexer.h"

static int peek(Lexer *L) {
  return L->src[L->pos];
}

static int advance(Lexer *L) {
  int c = L->src[L->pos++];
  if (c == '\n') {
    L->line++;
    L->col = 1;
  } else {
    L->col++;
  }
  return c;
}

static int match(Lexer *L, char expected) {
  if (peek(L) == expected) {
    advance(L);
    return 1;
  }
  return 0;
}

static Token make(Lexer *L, TokenType t, const char *lex) {
  Token tok = { t, lex, L->line, L->col, 0 };
  return tok;
}

void lexer_init(Lexer *L, const char *src) {
  L->src = src;
  L->pos = 0;
  L->line = 1;
  L->col = 1;
}

static void skip_spaces(Lexer *L) {
  for (;;) {
    int c = peek(L);
    if (c == '\0') break;
    if (isspace(c)) {
      advance(L);
      continue;
    }
    if (c == '/' && L->src[L->pos + 1] == '/') {
      while (peek(L) != '\0' && peek(L) != '\n') {
        advance(L);
      }
      continue;
    }
    break;
  }
}

Token lexer_next(Lexer *L) {
  skip_spaces(L);
  int c = peek(L);
  if (c == '\0') {
    return make(L, T_EOF, "");
  }

  if (isalpha(c) || c == '_') {
    int start = L->pos;
    while (isalnum(peek(L)) || peek(L) == '_') {
      advance(L);
    }
    int len = L->pos - start;
    char *buf = malloc(len + 1);
    memcpy(buf, &L->src[start], len);
    buf[len] = '\0';

    if (strcmp(buf, "let") == 0) {
      free(buf);
      return (Token){ T_LET, "let", L->line, L->col, 0 };
    }
    if (strcmp(buf, "print") == 0) {
      free(buf);
      return (Token){ T_PRINT, "print", L->line, L->col, 0 };
    }
    if (strcmp(buf, "if") == 0) {
      free(buf);
      return (Token){ T_IF, "if", L->line, L->col, 0 };
    }
    if (strcmp(buf, "else") == 0) {
      free(buf);
      return (Token){ T_ELSE, "else", L->line, L->col, 0 };
    }
    if (strcmp(buf, "while") == 0) {
      free(buf);
      return (Token){ T_WHILE, "while", L->line, L->col, 0 };
    }

    Token tk = (Token){ T_IDENT, buf, L->line, L->col, 0 };
    return tk;
  }

  if (isdigit(c)) {
    long v = 0;
    while (isdigit(peek(L))) {
      v = v * 10 + (advance(L) - '0');
    }
    return (Token){ T_NUMBER, "", L->line, L->col, v };
  }

  advance(L);
  switch (c) {
    case '=':
      if (match(L, '=')) return (Token){ T_EQ, "==", L->line, L->col, 0 };
      return (Token){ T_ASSIGN, "=", L->line, L->col, 0 };
    case '!':
      if (match(L, '=')) return (Token){ T_NEQ, "!=", L->line, L->col, 0 };
      return (Token){ T_NOT, "!", L->line, L->col, 0 };
    case '<':
      if (match(L, '=')) return (Token){ T_LTE, "<=", L->line, L->col, 0 };
      return (Token){ T_LT, "<", L->line, L->col, 0 };
    case '>':
      if (match(L, '=')) return (Token){ T_GTE, ">=", L->line, L->col, 0 };
      return (Token){ T_GT, ">", L->line, L->col, 0 };
    case '&':
      if (match(L, '&')) return (Token){ T_AND, "&&", L->line, L->col, 0 };
      break;
    case '|':
      if (match(L, '|')) return (Token){ T_OR, "||", L->line, L->col, 0 };
      break;
    case '+': return (Token){ T_PLUS, "+", L->line, L->col, 0 };
    case '-': return (Token){ T_MINUS, "-", L->line, L->col, 0 };
    case '*': return (Token){ T_STAR, "*", L->line, L->col, 0 };
    case '/': return (Token){ T_SLASH, "/", L->line, L->col, 0 };
    case '%': return (Token){ T_PERCENT, "%", L->line, L->col, 0 };
    case '(': return (Token){ T_LPAREN, "(", L->line, L->col, 0 };
    case ')': return (Token){ T_RPAREN, ")", L->line, L->col, 0 };
    case '{': return (Token){ T_LBRACE, "{", L->line, L->col, 0 };
    case '}': return (Token){ T_RBRACE, "}", L->line, L->col, 0 };
    case ';': return (Token){ T_SEMI, ";", L->line, L->col, 0 };
  }

  fprintf(stderr, "[lex] caractere inválido '%c' em %d:%d\n",
          c, L->line, L->col);
  return (Token){ T_EOF, "", L->line, L->col, 0 };
}
