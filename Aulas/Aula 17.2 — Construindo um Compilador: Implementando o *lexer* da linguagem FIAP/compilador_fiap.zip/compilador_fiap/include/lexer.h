#pragma once
#include "token.h"

typedef struct {
  const char *src;
  int pos;
  int line, col;
} Lexer;

void lexer_init(Lexer *L, const char *src);
Token lexer_next(Lexer *L);
